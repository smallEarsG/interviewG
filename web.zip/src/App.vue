<template>
  <router-view />
</template>

<style>
* {
  margin: 0;
  padding: 0;
}
/* .el-main{
    --el-main-padding: none !important;
    } */
.el-input__wrapper {
  
}
.el-tabs__nav {
          background: #fff !important;
}
.el-tabs--card>.el-tabs__header {
          margin: 0 !important;
        }
        .el-textarea__inner {
          background: #eeecec !important;  
        }
</style>